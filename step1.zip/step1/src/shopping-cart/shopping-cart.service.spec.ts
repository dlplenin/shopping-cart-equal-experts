import { ShoppingCartService } from './shopping-cart.service';

describe('ShoppingCartService', () => {
  it('should start with empty an ShoppingCart', () => {
    const shoppingCart = new ShoppingCartService();
    expect(shoppingCart.length()).toBe(0);
  });

  it('should add items properly', () => {
    const shoppingCart = new ShoppingCartService();
    const product = {
      name: 'Dove Soap',
      price: 39.99,
    };

    shoppingCart.addItem(product);

    expect(shoppingCart.length()).toBe(1);
  });

  it('should -add products to the shopping cart- and return shopping cart data properly', () => {
    // Given
    const shoppingCart = new ShoppingCartService();
    const product = {
      name: 'Dove Soap',
      price: 39.99,
    };

    // When
    shoppingCart.addWithQty(product, 5);
    const howManyByNameResponse = shoppingCart.howManyOfNameAndPrice(
      'Dove Soap',
      39.99,
    );
    const totalResponse = shoppingCart.total();

    // Then
    expect(howManyByNameResponse).toBe(5);

    expect(totalResponse).toEqual(199.95);
  });
});

// Not exported function
describe('Round to 2 decimal places', () => {
  it('should return 1.01 if calculated value is 1.05', () => {
    const shoppingCart = new ShoppingCartService();
    const product = {
      name: 'Dove Soap',
      price: 1.005,
    };

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(1.01);
  });

  it('should return 0.57 if calculated value is 0.565', () => {
    const shoppingCart = new ShoppingCartService();
    const product = {
      name: 'Dove Soap',
      price: 0.565,
    };

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(0.57);
  });

  it('should return 0.56 if calculated value is 0.5649', () => {
    const shoppingCart = new ShoppingCartService();
    const product = {
      name: 'Dove Soap',
      price: 0.5649,
    };

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(0.56);
  });
});
