import { Injectable } from '@nestjs/common';

@Injectable()
export class ShoppingCartService {
  private cartItems: Array<any> = [];

  length(): number {
    return this.cartItems.length;
  }

  addItem(item: any): void {
    this.cartItems.push(item);
  }

  addWithQty(item: any, qty: number): void {
    for (let i = 0; i < qty; i++) {
      this.addItem(item);
    }
  }

  howManyOfNameAndPrice(productName: string, price: number): any {
    return this.cartItems.filter(
      (item) => item.name === productName && item.price === price,
    ).length;
  }

  total() {
    const reduce = (accumulator: number, currentValue: any) =>
      accumulator + currentValue.price;
    const totalPrice = this.cartItems.reduce(reduce, 0);

    return this.roundToTwo(totalPrice);
  }

  roundToTwo(price: number) {
    return Math.round((price + Number.EPSILON) * 100) / 100;
  }
}
