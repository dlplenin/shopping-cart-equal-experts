## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Prerequisites 
Please make sure that Node.js (>= 10.13.0, except for v13) is installed on your operating system.
[docs.nestjs.com](https://docs.nestjs.com/first-steps#prerequisites)

You can check if you already have it installed on your computer:
```bash
$ node -v
```
_The output on the local computer used for this development is v16.15.0_

## Installation

```bash
$ npm install
```

## Test

```bash
# unit tests
$ npm run test

# unit tests watch
$ npm run test:watch

# test coverage
$ npm run test:cov
```

## Version number
5b8d0fd276b6d288905ed2f63a934e057e8feca2
