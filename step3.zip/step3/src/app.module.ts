import { Module } from '@nestjs/common';
import { ShoppingCartService } from './shopping-cart/shopping-cart.service';

@Module({
  imports: [],
  controllers: [],
  providers: [ShoppingCartService],
})
export class AppModule {}
