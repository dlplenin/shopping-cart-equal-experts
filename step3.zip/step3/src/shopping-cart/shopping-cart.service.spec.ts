import { ShoppingCartService } from './shopping-cart.service';

const getProductItem = (name: string, price: number) => ({
  name,
  price,
});

describe('ShoppingCartService', () => {
  it('should start with empty an ShoppingCart', () => {
    const shoppingCart = new ShoppingCartService();
    expect(shoppingCart.length()).toBe(0);
  });

  it('should add items properly', () => {
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 39.99);

    shoppingCart.addItem(product);

    expect(shoppingCart.length()).toBe(1);
  });

  it('should -add products to the shopping cart- and return shopping cart data properly', () => {
    // Given
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 39.99);

    // When
    shoppingCart.addWithQty(product, 5);
    const howManyByNameResponse = shoppingCart.howManyOfNameAndPrice(
      'Dove Soap',
      39.99,
    );
    const totalResponse = shoppingCart.total();

    // Then
    expect(howManyByNameResponse).toBe(5);

    expect(totalResponse).toEqual(199.95);
  });

  it('should -Add additional products of the same type to the shopping cart- and return shopping cart data properly', () => {
    // Given
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 39.99);

    // When
    shoppingCart.addWithQty(product, 5);
    shoppingCart.addWithQty(product, 3);
    const howManyByNameResponse = shoppingCart.howManyOfNameAndPrice(
      'Dove Soap',
      39.99,
    );
    const totalResponse = shoppingCart.total();

    // Then
    expect(howManyByNameResponse).toBe(8);

    expect(totalResponse).toEqual(319.92);
  });

  it('should -Calculate the tax rate of the shopping cart with multiple items- and return shopping cart data properly', () => {
    // Given
    const shoppingCart = new ShoppingCartService(12.5);
    const productDove = getProductItem('Dove Soap', 39.99);
    const productAxe = getProductItem('Axe Deo', 99.99);

    // When
    shoppingCart.addWithQty(productDove, 2);
    shoppingCart.addWithQty(productAxe, 2);
    const howManyDove = shoppingCart.howManyOfNameAndPrice('Dove Soap', 39.99);
    const howManyAxe = shoppingCart.howManyOfNameAndPrice('Axe Deo', 99.99);
    const totalResponse = shoppingCart.total();
    const totalSalesTaxAmount = shoppingCart.taxAmount();

    // Then
    expect(howManyDove).toBe(2);
    expect(howManyAxe).toBe(2);
    expect(totalSalesTaxAmount).toBe(35);

    expect(totalResponse).toEqual(314.96);
  });
});

// Not exported function
describe('Round to 2 decimal places', () => {
  it('should return 1.01 if calculated value is 1.05', () => {
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 1.005);

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(1.01);
  });

  it('should return 0.57 if calculated value is 0.565', () => {
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 0.565);

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(0.57);
  });

  it('should return 0.56 if calculated value is 0.5649', () => {
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 0.5649);

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(0.56);
  });

  it('should return 35 if calculated value is 34.995', () => {
    const shoppingCart = new ShoppingCartService();
    const product = getProductItem('Dove Soap', 34.995);

    shoppingCart.addItem(product);
    const totalResponse = shoppingCart.total();

    expect(totalResponse).toEqual(35);
  });
});
