import { Injectable } from '@nestjs/common';

@Injectable()
export class ShoppingCartService {
  constructor(taxRate = 0) {
    this.taxRate = taxRate;
  }

  private cartItems: Array<any> = [];
  private taxRate: number;
  private grossTotalAmount = 0;

  length(): number {
    return this.cartItems.length;
  }

  addItem(item: any): void {
    this.cartItems.push(item);
    this.grossTotalAmount += item.price;
  }

  addWithQty(item: any, qty: number): void {
    for (let i = 0; i < qty; i++) {
      this.addItem(item);
    }
  }

  howManyOfNameAndPrice(productName: string, price: number): any {
    return this.cartItems.filter(
      (item) => item.name === productName && item.price === price,
    ).length;
  }

  total() {
    return this.roundToTwo(this.grossTotalAmount + this.taxAmount());
  }

  taxAmount() {
    return this.roundToTwo((this.grossTotalAmount * this.taxRate) / 100);
  }

  roundToTwo(price: number) {
    return +(Math.round(Number(price + 'e+2')) + 'e-2');
  }
}
